@extends('layouts.app')

@section('content')
<div class="container">
    <h1 class="mb-3">Listado de Movimientos</h1>

    <a href="{{ route('movimientos.create') }}" class="btn btn-primary mb-3">Nuevo Movimiento</a>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha</th>
                <th>Cantidad</th>
                <th>Observacion</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @forelse($movimientos as $movimiento)
                <tr>
                    <td>{{ $movimiento->id }}</td>
                    <td>{{ $movimiento->fecha }}</td>
                    <td>{{ $movimiento->cantidad }}</td>
                    <td>{{ $movimiento->observacion }}</td>
                    <td>{{ $movimiento->estado }}</td>
                    <td>
                        <a href="{{ route('movimientos.edit', $movimiento) }}" class="btn btn-sm btn-warning">Editar</a>
                        <form action="{{ route('movimientos.destroy', $movimiento) }}" method="movimiento" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar este movimiento?')">
                                Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5">No hay movimientos registrados.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection