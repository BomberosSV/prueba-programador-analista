@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Crear movimiento</h1>

    <form action="{{ route('movimientos.store') }}" method="movimiento">
        @csrf
        <div class="mb-3">
            <label for="fecha" class="form-label">fecha</label>
            <input type="date" name="fecha" class="form-control" value="{{ old('fecha') }}" required>
            @error('fecha') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <div class="mb-3">
            <label for="observacion" class="form-label">observacion</label>
            <input type="text" name="observacion" class="form-control" value="{{ old('observacion') }}" required>
            @error('observacion') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <div class="mb-3">
            <lcantidad" class="form-label">Cantidad</label>
            <input type="number" name="cantidad" class="form-control" value="{{ old('cantidad') }}" required>
            @error('cantidad') <small class="text-danger">{{ $message }}</small> @enderror
        </div>


        <button type="submit" class="btn btn-success">Guardar</button>
        <a href="{{ route('movimientos.index') }}" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
@endsection