<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MovimientoController;
Route::get('/', function () {
    return view('welcome');
});

Route::resource('movimientos', MovimientoController::class);
