<?php

namespace App\Http\Controllers;

use App\Models\Suministro;
use Illuminate\Http\Request;

class SuministroController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Suministro $suministro)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Suministro $suministro)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Suministro $suministro)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Suministro $suministro)
    {
        //
    }
}
