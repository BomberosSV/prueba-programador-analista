<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Suministro extends Model
{
    protected $table = "suministros";
    protected $fillable = [
        'codigo', 'nombre', 'fecha', "cantidad", "estado"
    ];
    protected $timestamp = true;
}
