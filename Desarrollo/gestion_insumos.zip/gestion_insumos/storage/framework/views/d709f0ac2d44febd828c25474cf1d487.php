

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-3">Listado de Movimientos</h1>

    <a href="<?php echo e(route('movimientos.create')); ?>" class="btn btn-primary mb-3">Nuevo Movimiento</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha</th>
                <th>Cantidad</th>
                <th>Observacion</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($movimiento->id); ?></td>
                    <td><?php echo e($movimiento->fecha); ?></td>
                    <td><?php echo e($movimiento->cantidad); ?></td>
                    <td><?php echo e($movimiento->observacion); ?></td>
                    <td><?php echo e($movimiento->estado); ?></td>
                    <td>
                        <a href="<?php echo e(route('movimientos.edit', $movimiento)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('movimientos.destroy', $movimiento)); ?>" method="movimiento" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar este movimiento?')">
                                Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">No hay movimientos registrados.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\gestion_insumos\resources\views/movimientos/index.blade.php ENDPATH**/ ?>