

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Crear movimiento</h1>

    <form action="<?php echo e(route('movimientos.store')); ?>" method="movimiento">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="fecha" class="form-label">fecha</label>
            <input type="date" name="fecha" class="form-control" value="<?php echo e(old('fecha')); ?>" required>
            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="observacion" class="form-label">observacion</label>
            <input type="text" name="observacion" class="form-control" value="<?php echo e(old('observacion')); ?>" required>
            <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <lcantidad" class="form-label">Cantidad</label>
            <input type="number" name="cantidad" class="form-control" value="<?php echo e(old('cantidad')); ?>" required>
            <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <button type="submit" class="btn btn-success">Guardar</button>
        <a href="<?php echo e(route('movimientos.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\gestion_insumos\resources\views/movimientos/create.blade.php ENDPATH**/ ?>